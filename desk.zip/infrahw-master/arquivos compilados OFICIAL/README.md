# infrahw
...
padrão usado na implementação é:
module NOME(sinais de controle,...,inputs,...,outputs)
blabla

endmodule
